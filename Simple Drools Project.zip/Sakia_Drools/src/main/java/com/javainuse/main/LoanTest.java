/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.javainuse.main;

/**
 *
 * @author Sakia Chowdhury
 */

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import org.drools.compiler.compiler.DroolsParserException;
import org.drools.compiler.compiler.PackageBuilder;
import org.drools.core.RuleBase;
import org.drools.core.RuleBaseFactory;
import org.drools.core.WorkingMemory;

import com.javainuse.model.Loan;
import java.util.Scanner;

public class LoanTest {
    
    public static void main(String[] args) throws DroolsParserException,
			IOException {
		LoanTest loanTest = new LoanTest();
		loanTest.executeDrools();
	}

	public void executeDrools() throws DroolsParserException, IOException {

		PackageBuilder packageBuilder = new PackageBuilder();

		String ruleFile = "/com/rule/Rules.drl";
		InputStream resourceAsStream = getClass().getResourceAsStream(ruleFile);

		Reader reader = new InputStreamReader(resourceAsStream);
		packageBuilder.addPackageFromDrl(reader);
		org.drools.core.rule.Package rulesPackage = packageBuilder.getPackage();
		RuleBase ruleBase = RuleBaseFactory.newRuleBase();
		ruleBase.addPackage(rulesPackage);

		WorkingMemory workingMemory = ruleBase.newStatefulSession();

		Loan loan = new Loan();
                
                System.out.println();
                Scanner sc = new Scanner(System.in);
                System.out.println("Please enter the property amount: ");
                int amount = sc.nextInt();
		loan.setProperty(amount);
                
                System.out.println("Please enter the age: ");
                int age = sc.nextInt();
		loan.setAge(age);

		workingMemory.insert(loan);
		workingMemory.fireAllRules();

		System.out.println("The loan possible for " + loan.getProperty() + " taka property"
				+ " is " + loan.getLoan() +"%" + " of the property");
	}
    
}

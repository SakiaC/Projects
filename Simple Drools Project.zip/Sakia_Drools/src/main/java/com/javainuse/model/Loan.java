/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.javainuse.model;

/**
 *
 * @author Sakia Chowdhury
 */
public class Loan {
    
    private int property;
    private int age;
    private int loan;

    public int getProperty() {
        return property;
    }

    public int getAge() {
        return age;
    }

    public int getLoan() {
        return loan;
    }

    public void setProperty(int property) {
        this.property = property;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setLoan(int loan) {
        this.loan = loan;
    }
    
    
    
}

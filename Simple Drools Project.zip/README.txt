
***Application details****

Consider a Loan giving structure of a bank:

If the person has minimum property of 2,50,000 taka and

i. if his/her age is between 30 to 42 years then he/she can get a loan of 57% of the property.

ii. if his/her age is between 43 to 51 years then he/she can get a loan of 24% of the property.




***In order to run the application***

1. Run the "LoanTest.java" file.

2. It will ask you to enter property amount and age of the user.

3. If the user details are met by the bank's loan giving requirements then a specific percentage of loan is given to the user.





***In order to run the program***

1. In order to run the python file make sure Apache Spark
   and Python is installed in your computer.

2. Paste the Python file inside c:\spark\bin

3. Before running the code, change the path of the dataset 
   files in Line 8 and Line 22 of the Python file.

4. Run cmd as administrator. Enter "cd c:\spark\bin". 
   Then enter "spark-submit recommender-system.py USERID". 
   USERID refers to any user that is present in the
   ratings.data file.


***Things to know***

1. I have used the 100k dataset from movielens since 
   the larger datasets were not working on my PC. Apache
   Spark was getting crashed because of memory issue.

2. I was asked to find the predicted ratings of movies for
   a completely new user means a user who has not yet rated 
   any of the given movies.

   But the recommender system works in the following way-

   If USER A liked MOVIE1 and MOVIE2 and USER B liked MOVIE1
   then there is a chance that USER B will also like MOVIE2.
   So what the system does is, it recommends USER B with
   MOVIE2.
   
   Therefore, if any user does not have any previous 
   preferences recorded in the system and he/she will
   not get any kind of recommendation.
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class frame1 extends JFrame implements ActionListener
{
  private JLabel label;
  private JRadioButton option1;
  private JRadioButton option2;
  private JRadioButton option3;
  private JRadioButton option4;
  private ButtonGroup radioGroup;
  private JButton next;
  private JButton previous;
  public Boolean mark[];
 
  public frame1(Boolean [] mark)
  {
   
    super("Online Examination System");
    this.mark = mark;
    label = new JLabel("1. What is the capital of Bangladesh ?");
    add(label);
    
    option1 = new JRadioButton("Dhaka");
    option2 = new JRadioButton("Sylhet");
    option3 = new JRadioButton("Mumbai");
    option4 = new JRadioButton("New York");
    
    add(option1);
    add(option2);
    add(option3);
    add(option4);
    
    radioGroup = new ButtonGroup();
    radioGroup.add(option1);
    radioGroup.add(option2);
    radioGroup.add(option3);
    radioGroup.add(option4);
    
    next = new JButton("NEXT"); 
    next.addActionListener(this);
    
add(next);  

label.setBounds(80,50,450,20);
option1.setBounds(75,100,300,30);
option2.setBounds(75,150,300,30);
option3.setBounds(75,200,300,30);
option4.setBounds(75,250,300,30);
next.setBounds(400,300,100,40);
setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);    
setSize(600,400);    
setLayout(null);
setVisible(true); 
  }
  
   public void actionPerformed(ActionEvent e) 
    {
        if(option1.isSelected())
        mark[0] = true;
        else
        mark[0] = false;  
        
        
        option1.setSelected(true);
        System.out.println(mark[0]);
        
        dispose();
        
        frame2 f2 = new frame2(mark);
    
      
   }
  
}
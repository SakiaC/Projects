import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class frame0 extends JFrame implements ActionListener
{
  private JLabel label, label2;
//  private JRadioButton option1;
//  private JRadioButton option2;
//  private JRadioButton option3;
//  private JRadioButton option4;
//  private ButtonGroup radioGroup;
  private JButton start;
//  private JButton previous;
  public Boolean mark[];
 
  public frame0(Boolean [] mark)
  {
   
    super("Online Examination System");
    this.mark = mark;
    label = new JLabel("The online exam contains 10 questions");
    label2 = new JLabel("One mark for each question");
    add(label); add(label2);
    
//    option1 = new JRadioButton("Dhaka");
//    option2 = new JRadioButton("Sylhet");
//    option3 = new JRadioButton("Mumbai");
//    option4 = new JRadioButton("New York");
//    
//    add(option1);
//    add(option2);
//    add(option3);
//    add(option4);
//    
//    radioGroup = new ButtonGroup();
//    radioGroup.add(option1);
//    radioGroup.add(option2);
//    radioGroup.add(option3);
//    radioGroup.add(option4);
    
    start = new JButton("Start"); 
    start.addActionListener(this);
    
add(start);  

label.setBounds(80,50,450,20);
label2.setBounds(80,70,450,20);
//option1.setBounds(75,100,300,30);
//option2.setBounds(75,150,300,30);
//option3.setBounds(75,200,300,30);
//option4.setBounds(75,250,300,30);
start.setBounds(400,300,100,40);
setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);    
setSize(600,400);    
setLayout(null);
setVisible(true); 
  }
  
   public void actionPerformed(ActionEvent e) 
    {
//        if(option1.isSelected())
//        mark[0] = true;
//        else
//        mark[0] = false;  
//        
//        System.out.println(mark[0]);
//        
        dispose();
        
        frame1 f1 = new frame1(mark);
    
      
   }
  
}
import javax.swing.JFrame;


public class main
{
  public static void main (String args[])
  {
    Boolean [] mark = new Boolean[10];
    
    frame0 f0 = new frame0(mark);
  }
}
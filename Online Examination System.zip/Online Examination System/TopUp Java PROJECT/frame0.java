import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class frame0 extends JFrame implements ActionListener
{
  private JLabel label, label2;
  private JButton start;
  public Boolean mark[];
 
  public frame0(Boolean [] mark)
  {
   
    super("Online Examination System");
    this.mark = mark;
    label = new JLabel("The online exam contains 10 questions");
    label2 = new JLabel("One mark for each question");
    add(label); add(label2);
    
    start = new JButton("Start"); 
    start.addActionListener(this);
    
add(start);  

label.setBounds(80,50,450,20);
label2.setBounds(80,70,450,20);

start.setBounds(400,300,100,40);
setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);    
setSize(600,400);    
setLayout(null);
setVisible(true); 
  }
  
   public void actionPerformed(ActionEvent e) 
    {
        dispose();
        
        frame1 f1 = new frame1(mark); 
   }
  
}
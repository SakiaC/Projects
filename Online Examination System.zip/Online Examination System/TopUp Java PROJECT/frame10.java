import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class frame10 extends JFrame implements ActionListener
{
  private JLabel label;
  private JRadioButton option1;
  private JRadioButton option2;
  private JRadioButton option3;
  private JRadioButton option4;
  private ButtonGroup radioGroup;
  private JButton result;
  private JButton previous;
  public Boolean mark[];
  public int count;
 
  public frame10(Boolean [] mark)
  {
   
    super("Online Examination System");
    this.mark = mark;
    label = new JLabel("10. 49 * 2 ?");
    add(label);
    
    option1 = new JRadioButton("3");
    option2 = new JRadioButton("98");
    option3 = new JRadioButton("14");
    option4 = new JRadioButton("21");
    
    add(option1);
    add(option2);
    add(option3);
    add(option4);
    
    radioGroup = new ButtonGroup();
    radioGroup.add(option1);
    radioGroup.add(option2);
    radioGroup.add(option3);
    radioGroup.add(option4);
    
    result = new JButton("Show Result");
    previous = new JButton("PREVIOUS");
    result.addActionListener(this);
    previous.addActionListener(this);
    
add(result);
add(previous);    
    
label.setBounds(80,50,450,20);
option1.setBounds(75,100,300,30);
option2.setBounds(75,150,300,30);
option3.setBounds(75,200,300,30);
option4.setBounds(75,250,300,30);
result.setBounds(400,300,120,40);
previous.setBounds(100,300,100,40);
setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);    
setSize(600,400);    
setLayout(null);
setVisible(true); 
  }
  
   public void actionPerformed(ActionEvent e) 
    {
      if (e.getSource() == result) 
      {
        if(option2.isSelected())
        mark[9] = true;
        else
        mark[9] = false;
        
        dispose();
        
        for(int i = 0; i < mark.length; i++)
        {
          if(mark[i] == true)
            count++;
        }
        
        JOptionPane.showMessageDialog(this, "Your mark is : " + count);
       
    
      } 
      else 
      {
        if(option2.isSelected())
        mark[9] = true;
        else
        mark[9] = false;
        
        dispose();
        
        frame9 f9 = new frame9(mark);
        
       
      }
    }
    
  
}